package me.frep.vulcan.spigot.util.nms;

public interface IStringSerializable
{
    String getName();
}
