package me.frep.vulcan.spigot.id;

public class ID
{
    public static String spigot() {
        return "%%__USER__%%";
    }
    
    public static String nonce() {
        return "%%__NONCE__%%";
    }
    
    public static String resource() {
        return "%%__RESOURCE__%%";
    }
}
